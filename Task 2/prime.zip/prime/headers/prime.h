/*
 * Created  by rbh, 30/01/11
 * Modified by nas, 09/09/16
 * Modified by nas, 28/03/17
 */

#ifndef PRIME_RBH300111
#define PRIME_RBH300111

bool isPrime(int);

#endif
